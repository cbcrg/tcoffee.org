#ifndef XML_H_
#define XML_H_

#include <string>
#include <cstring>
#include <cstdio>
#include <cstdlib>
std::string
find_best_pdb(unsigned int min_coverage, unsigned int min_identity, const std::string &xml_f );



#endif // REST_H_