/**
*   This file is part of STRIKE.
*
*   STRIKE is free software: you can redistribute it and/or modify
*   it under the terms of the GNU Lesser General Public License as published by
*   the Free Software Foundation, either version 3 of the License, or
*   (at your option) any later version.
*
*   STRIKE is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public License
*   along with STRIKE.  If not, see <http://www.gnu.org/licenses/>.
*
*/

/*
 * main.cpp
 *
 *  Created on: Nov 12, 2010
 *      Author: Carsten Kemena
 */


#include <cstring>
#include <cmath>

// My own
#include "classes/PDB.h"
#include "classes/Contacts.h"
#include "classes/Alignment.h"
// #include "classes/RestServices.h"
// #include "util/xml.h"

#ifdef _OPENMP
	#include <omp.h>
#endif



using namespace std;




void
print_help()
{
	printf("Program: STRIKE  v1.1\n");
	printf("-a <file> --alignment      Alignment File\n");
	printf("-c <file> --template_file  Connection File\n");
	printf("-n --normalize             Normalizes the score\n");
	printf("-o <file> --out_file       The file where the results will be saved\n");
// 	printf("-p <dir>  --pdb            Downloads pdb and saves them in the given directory\n");
// 	printf("-e <email address> --email  The email address (only needed in combinatino with -p|--pdb\n");
	#ifdef _OPENMP
	printf("--nc                       Number of cores to use\n");
	#endif
}



int
main(int argc, char *argv[])
{
	char *aln_f = NULL;
	char *connection_f = NULL;
	char *out_f = NULL;
// 	char *email = NULL;
// 	char *pdb_dir = NULL;
	bool normalize = false;

/*

	PDB pdb2;
	pdb2.read_pdb(argv[1], true);
	Contacts *contacts3 = pdb2.calculate_contacts(argv[2][0], atoi(argv[3]), "test");
	if (contacts3 != NULL)
	contacts3->print();
	exit(0);*/


	#ifdef _OPENMP
	int ncore = 1;
// 	ncore = omp_get_num_procs();
	#endif

	// option parsing
	if (argc == 1)
	{
		print_help();
		return 0;
	}
	int i = 1;
	while (i < argc)
	{
		if (argv[i][0] == '-')
		{
			if (!strcmp(argv[i],"-a"))
			{
				aln_f = argv[++i];
			}
			else if ((!strcmp(argv[i],"-c")) || (!strcmp(argv[i],"--template_file")))
			{
				connection_f = argv[++i];
			}
			else if ((!strcmp(argv[i],"-o")) || (!strcmp(argv[i],"--out_file")))
			{
				out_f = argv[++i];
			}
// 			else if ((!strcmp(argv[i],"-e")) || (!strcmp(argv[i],"--email")))
// 			{
// 				email = argv[++i];
// 			}
// 			else if ((!strcmp(argv[i],"-p")) || (!strcmp(argv[i],"--pdb_dir")))
// 			{
// 				pdb_dir = argv[++i];
// 			}
			else if ((!strcmp(argv[i],"-n")) | (!strcmp(argv[i],"--normalize")))
			{
				normalize = true;
			}
			#ifdef _OPENMP
			else if (!strcmp(argv[i],"--nc"))
			{
				ncore = atoi(argv[++i]);
			}
			#endif
			else if ((!strcmp(argv[i],"-h")) || (!strcmp(argv[i],"--help")))
			{
				print_help();
				return 0;
			}
			else
			{
				fprintf(stderr, "ERROR! Unkown parameter! Use -h or --help to see input information!");
				exit(1);
			}
		}
		++i;
	}

	#ifdef _OPENMP
		omp_set_num_threads(ncore);
	#endif


	// 	read alignment
	Alignment aln;
	aln.read_alignment(aln_f);


// 	// get pdb_files
// 	if (pdb_dir!= NULL)
// 	{
// 		get_pdb_files(email, pdb_dir, aln, aln_f);
// 		return 0;
// 	}


//  read connection file and calculate contacts
	FILE *connection_F = fopen(connection_f, "r");
	if (connection_F == NULL)
	{
		fprintf(stderr, "ERROR! Connection file: %s not found.\n", connection_f);
		exit(1);
	}


	const unsigned int READ_LENGTH = 501;
	char line[READ_LENGTH];


	char *info[4];
	char chain;
	vector<Contacts *> contacts;

	// format: seq_name optional: _P_ pdb_name optional: chain
	while (fgets(line, READ_LENGTH, connection_F) != NULL)
	{
		if (line[0] != '\n')
		{
			i = -1;
			info[++i] = strtok(line, " \t\n");
			while ((info[++i] = strtok(NULL, " \t\n") )!= NULL)
			{
				if (!strcmp(info[i], "_P_"))
					--i;
			}
			PDB pdb;
			pdb.read_pdb(info[1], true);
			if ((info[2] == NULL) || (strlen(info[2]) > 1))
				chain = '#';
			else
				chain = info[2][0];

			contacts.push_back(pdb.calculate_contacts(chain, 5, info[0]));
		}

	}
	fclose(connection_F);


// 	score alignment
	unsigned int k;
	double avg = 0;
	unsigned int tmp_num = contacts.size();
	FILE *out_F;
	if (out_f == NULL)
		out_F = stdout;
	else
		out_F = fopen(out_f, "w");
	double x;
	for (k = 0; k < tmp_num; ++k)
	{
		x = aln.score_cs(*contacts[k], 0, normalize);
		avg += x;
		fprintf(out_F, "%s\n%.2f\n", contacts[k]->get_seq_name().c_str(), x);
	}
	fprintf(out_F, "AVG\n%.2f\n", avg/tmp_num);

	for (k = 0; k < contacts.size(); ++k)
	{
		delete contacts[k];
	}

 return 0;
}
