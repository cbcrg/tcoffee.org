/*
 * main.cpp
 *
 *  Created on: Nov 12, 2010
 *      Author: Carsten Kemena
 */


#include "string.h"
#include "math.h"


#include "classes/PDB.h"
#include "classes/Contacts.h"
#include "classes/Alignment.h"

#ifdef _OPENMP
	#include <omp.h>
#endif



using namespace std;




void
print_help()
{
	printf("Program: STRIKE  v. 1.0\n");
	printf("-a <file>                  Alignment File\n");
	printf("-c <file> -template_file   Connection File\n");
	printf("-n --normalize             Normalizes the score\n");
	printf("-o <file>  --out_file      The file where the results will be saved\n");
	#ifdef _OPENMP
	printf("--nc                       Number of cores to use\n");
	#endif
}



int
main(int argc, char *argv[])
{
	char *aln_f = NULL;
	char *connection_f = NULL;
	char *out_f = NULL;
	bool normalize = false;
	bool cao = false;

	int ncore = 0;
	#ifdef _OPENMP
	ncore = omp_get_num_procs();
	#endif

// 	bool contacts_only = false;


	// option parsing
	if (argc == 1)
	{
		print_help();
		return 0;
	}
	int i = 1;
	while (i < argc)
	{
		if (argv[i][0] == '-')
		{
			if (!strcmp(argv[i],"-a"))
			{
				aln_f = argv[++i];
			}
			else if ((!strcmp(argv[i],"-c")) || (!strcmp(argv[i],"-template_file")))
			{
				connection_f = argv[++i];
			}
			else if ((!strcmp(argv[i],"-o")) || (!strcmp(argv[i],"--out_file")))
			{
				out_f = argv[++i];
			}
			else if ((!strcmp(argv[i],"-n")) | (!strcmp(argv[i],"--normalize")))
			{
				normalize = true;
			}
			else if (!strcmp(argv[i],"--cao"))
			{
				cao = true;
			}
			else if (!strcmp(argv[i],"--nc"))
			{
				ncore = atoi(argv[++i]);
			}
			else if ((!strcmp(argv[i],"-h")) || (!strcmp(argv[i],"-help")))
			{
				print_help();
				return 0;
			}
		}
		++i;
	}

	#ifdef _OPENMP
		omp_set_num_threads(ncore);
	#endif

//  read connection file and calculate contacts
	FILE *connection_F = fopen(connection_f, "r");
	if (connection_F == NULL)
	{
		fprintf(stderr, "ERROR! Connection file: %s not found.\n", connection_f);
		exit(1);
	}
	const unsigned int READ_LENGTH = 501;
	char line[READ_LENGTH];

// 	char *seq_name, *pdb_f, *chain;
	char *info[4];
	char chain;
	vector<Contacts *> contacts;

	// format: seq_name optional: _P_ pdb_name optional: chain
	while (fgets(line, READ_LENGTH, connection_F) != NULL)
	{
		if (line[0] != '\n')
		{
			i = -1;
			info[++i] = strtok(line, " \n");
			while ((info[++i] = strtok(NULL, " \n") )!= NULL)
			{
				if (!strcmp(info[i], "_P_"))
					--i;
			}
			PDB pdb;
			pdb.read_pdb(info[1], true);
			if ((info[2] == NULL) || (strlen(info[2]) > 1))
				chain = '#';
			else
				chain = info[2][0];
// 			if (cao)
// 			{
// 				Contacts *c = new Contacts();
// 				c->set_seq_name(info[0]);
// 				c->read_contact_file(info[1], 1);
// 				contacts.push_back(c);
// 			}
// 			else
			contacts.push_back(pdb.calculate_contacts(chain, 1, info[0]));
		}

	}
	fclose(connection_F);



// 	read alignment
	Alignment aln;
	aln.read_alignment(aln_f);


// 	score alignment
	unsigned int k;
	double avg = 0;
	unsigned int tmp_num = contacts.size();
	FILE *out_F;
	if (out_f == NULL)
		out_F = stdout;
	else
		out_F = fopen(out_f, "w");
	double x;
	for (k = 0; k < tmp_num; ++k)
	{
// 		if (cao)
// 			x = aln.score_cao(*contacts[k], 5);
// 		else
		x = aln.score_cs(*contacts[k], 5, normalize);
		avg += x;
		fprintf(out_F, "%s\n%.2f\n", contacts[k]->get_seq_name().c_str(), x);
	}

	fprintf(out_F, "AVG\n%.2f\n", avg/tmp_num);


	for (k = 0; k < contacts.size(); ++k)
	{
		delete contacts[k];
	}


}
