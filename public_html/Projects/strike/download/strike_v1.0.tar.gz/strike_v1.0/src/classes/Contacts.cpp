/*
 * Contacts.cpp
 *
 *  Created on: Nov 13, 2010
 *      Author: Carsten Kemena
 */



#include "Contacts.h"

Contacts::Contacts()
{
	_num_contacts=0;
}


Contacts::Contacts(const char *pdb_f, char chain):_pdb_f(pdb_f),_chain(chain)
{
	_num_contacts = 0;
}


Contacts::Contacts(unsigned int seq_length, const char *pdb_f, char chain):_pdb_f(pdb_f),_chain(chain)
{
	_num_contacts = 0;
	_pairs.resize(seq_length);
}



// Contacts::Contacts(char *seq_name, char *pdb_f, char *chain, unsigned int min_distance):_seq_name(seq_name), _pdb_f(pdb_f), _chain(chain)
// {
// 	//cal perl
// 	char command[1000];
// 
// 	sprintf(command, "perl /users/cn/ckemena/projects/PDB/src/PDB_TOOL.pl %s %s > tmp_cont", _pdb_f.c_str(), _chain.c_str());
// 	printf("%s\n", command);
// 	system(command);
// 
// 	//read contacts
// 	read_contact_file("tmp_cont", min_distance);
// }


// Contacts::Contacts(string sequence):_sequence(sequence)
// {
// 	_num_contacts = 0;
// 	_pairs.resize(sequence.length());
// }




Contacts::~Contacts()
{
}


void
Contacts::print(char *contact_f)
{
	FILE *contact_F;
	if (contact_f != NULL)
		contact_F = fopen(contact_f, "w");
	else
		contact_F = stdout;
	unsigned int i, end = _sequence.length(), j, end2;
	fprintf(contact_F, "#Contact v1\n");
	fprintf(contact_F, "%i\n", end);
	fprintf(contact_F, "%s\n", _seq_name.c_str());
	fprintf(contact_F, "%s\n", _sequence.c_str());
	fprintf(contact_F, "%i\n", _num_contacts);
	for (i = 0; i < end; ++i)
	{
		end2 = _pairs[i].size();
		fprintf(contact_F, "%i:", i);
		for (j = 0; j < end2; ++j)
		{
			fprintf(contact_F, " %i", _pairs[i][j]);
		}
		fprintf(contact_F, "\n");
	}
	if (contact_f != NULL)
		fclose(contact_F);
}



void
Contacts::read_contact_file(char *contact_f, unsigned int min_distance)
{
	FILE *contact_F = fopen(contact_f, "r");
	if (contact_F == NULL)
	{
		fprintf(stderr, "Contact file %s could not be opened !\n", contact_f );
		exit(1);
	}
	const unsigned int READ_LENGTH = 201;
	char line[READ_LENGTH];

	//Read Sequence
	_sequence.clear();
	while (fgets(line, READ_LENGTH, contact_F) != NULL)
	{
		if (isdigit(line[0]))
		{
			break;
		}
		_sequence.append(line);
	}
	_sequence.erase(_sequence.length()-1, 1);
	
	unsigned int seq_length = _sequence.length();
	for (unsigned int i = 0; i < seq_length; ++i)
	{
		_sequence[i] = toupper(_sequence[i]);
	}

	//Read contacts
	_pairs.clear();
	_pairs.resize(seq_length);
	string tmp;
	while (fgets(line, READ_LENGTH, contact_F) != NULL)
	{
		tmp.append(line);
	}
	fclose(contact_F);

	_num_contacts = 0;
	unsigned int a = -1, b;
	unsigned int start = 0, end = 0;
	bool pair_end = false;

	seq_length = tmp.length();

	while (end < seq_length)
	{
		if ((tmp[end] == ' ') || (tmp[end] == '\n'))
		{
			if (pair_end)
			{
				pair_end = false;
				b = atoi((tmp.substr(start,end-start)).c_str());
				if (b-a >= min_distance)
				{
					add_pair(a,b);
				}
			}
			else
			{
				a = atoi((tmp.substr(start,end-start)).c_str());
				pair_end = true;
			}
			start = ++end;
		}
		else
		{
			++end;
		}
	}
	
}

