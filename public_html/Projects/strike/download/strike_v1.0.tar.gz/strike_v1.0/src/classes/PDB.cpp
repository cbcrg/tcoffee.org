/*
 * PDB.cpp
 *
 *  Created on: Nov 12, 2010
 *      Author: Carsten Kemena
 */




#include "PDB.h"



using namespace std;

Atom::Atom()
{

}


Atom::Atom(char chain_ID, unsigned int res_ID, char amino_accid, char *atom_name, unsigned int atom_serial_number, double x, double y, double z):_chain_ID(chain_ID),_res_ID(res_ID),_amino_accid(amino_accid),_atom_serial_number(atom_serial_number),_x(x),_y(y),_z(z)
{
	sprintf(_atom_name, "%s", atom_name);
}


Atom::~Atom()
{

}



double
Atom::radius()
{
	if (_atom_name[0] == 'O')
		return 1.40;
	else if (_atom_name[0] == 'N')
	{
		if (_atom_name[1] == 'Z')
			return 1.5;
		else
			return 1.65;
	}
	else if (_atom_name[0] == 'C')
	{
		if (_atom_name[1] == '\0')
			return 1.76;
		else
		{
			if ((_amino_accid == 'R') || (_amino_accid == 'N') || (_amino_accid == 'D') || (_amino_accid == 'E') || (_amino_accid == 'Q') || (_amino_accid == 'H') || (_amino_accid == 'F') || (_amino_accid == 'W') || (_amino_accid == 'Y') || (_amino_accid == 'B') || (_amino_accid == 'Z'))
			{
				if ( (_atom_name[1] == 'A') || (_atom_name[1] == 'B') || ( (_atom_name[1] == 'G') && ((_amino_accid == 'R') || (_amino_accid == 'E') || (_amino_accid =='Q'))) || ((_atom_name[1] == 'D') && (_amino_accid == 'R' )))
					return 1.87;
				else
					return 1.76;
			}
			else
				return 1.87;
		}
	}
	else if (_atom_name[0] == 'S')
		return 1.85;
	else if (_atom_name[0] == 'A')
		return 1.5;
	else if (_atom_name[0] == 'E')
		return 1.9;
	else if (_atom_name[0] == 'H')
		return 1.0;
	else
		return 0;
	
}






string
aa1_3(char amino_accid_name)
{
	switch (amino_accid_name)
	{
		case 'A': return "ALA";
		case 'R': return "ARG";
		case 'N': return "ASN";
		case 'D': return "ASP";
		case 'B': return "ASX";
		case 'C': return "CYS";
		case 'E': return "GLU";
		case 'Q': return "GLN";
		case 'Z': return "GLX";
		case 'G': return "GLY";
		case 'H': return "HIS";
		case 'I': return "ILE";
		case 'L': return "LEU";
		case 'K': return "LYS";
		case 'M': return "MET";
		case 'F': return "PHE";
		case 'P': return "PRO";
		case 'S': return "SER";
		case 'T': return "THR";
		case 'W': return "TRP";
		case 'Y': return "TYR";
		case 'V': return "VAL";
		case 'X': return "XAA";
		case 'U': return "CSE";
		default: return "NNN";
	}
}







PDB::PDB() {
	_aa["ALA"] = 'A';
	_aa["ARG"] = 'R';
	_aa["ASN"] = 'N';
	_aa["ASP"] = 'D';
	_aa["ASX"] = 'B';
	_aa["CYS"] = 'C';
	_aa["GLU"] = 'E';
	_aa["GLN"] = 'Q';
	_aa["GLX"] = 'Z';
	_aa["GLY"] = 'G';
	_aa["HIS"] = 'H';
	_aa["ILE"] = 'I';
	_aa["LEU"] = 'L';
	_aa["LYS"] = 'K';
	_aa["MET"] = 'M';
	_aa["PHE"] = 'F';
	_aa["PRO"] = 'P';
	_aa["SER"] = 'S';
	_aa["THR"] = 'T';
	_aa["TRP"] = 'W';
	_aa["TYR"] = 'Y';
	_aa["VAL"] = 'V';
	_aa["XAA"] = 'X';
	_aa["CSE"] = 'U';
}



PDB::~PDB() {
	delete[] _pdb_f;
}




void
PDB::read_pdb(const char *pdb_f, bool ignore_H)
{
	
	_num_chains = 0;
	char last_chain = ' ';
	FILE *pdb_F = fopen(pdb_f, "r");
	if (pdb_F == NULL)
	{
		fprintf(stderr, "ERROR: Could not open PDB file: %s\n", pdb_f);
		exit(1);
	}
	const char *tmp_name = strrchr(pdb_f,  '/');
	if (tmp_name == NULL)
		tmp_name = pdb_f;
	else
		++tmp_name;
	_pdb_f = new char[strlen(tmp_name)+1];
	sprintf(_pdb_f, tmp_name);
	int const LINE_LENGTH = 201;
	char line[LINE_LENGTH];
	unsigned int res_ID= 0, file_res_ID, old_res_ID=-999, atom_serial_number = 0;
	char amino_accid;
	char chain_ID;
	char *atom_name = new char[5];

	string seq;
	double x, y, z;

	unsigned int i, j;
	while (fgets(line, LINE_LENGTH, pdb_F) != NULL)
	{
		if (!strncmp( "ATOM", line, 4))
		{

			if (line[21] != last_chain)
			{
				++_num_chains;
				_sequences[last_chain] = seq;
				last_chain = line[21];
				_atom_list[last_chain] = vector< map< string, Atom> >();
				old_res_ID = -999;
				res_ID = 0;
				if (_num_chains > 1)
				{
					_sequences[last_chain] = seq;
				}
				seq.clear();
			}


			j = -1;
			for (i = 12; i < 16; ++i)
			{
				if (line[i] != ' ')
					atom_name[++j] = line[i];
			}
			atom_name[++j] = '\0';

			if ((ignore_H) && (atom_name[0] == 'H'))
				continue;


			line[11] = '\0';
			++atom_serial_number;


			line[20] = '\0';
			amino_accid = _aa3_1(&line[17]);
			if (amino_accid == '#')
				continue;
			chain_ID = line[21];

			line[26] = '\0';
			file_res_ID = atoi(&line[22]);
			if (old_res_ID != file_res_ID)
			{
				++res_ID;
				old_res_ID = file_res_ID;
				_atom_list[last_chain].push_back(map<string, Atom>());
				seq.push_back(amino_accid);
			}
			

			
			char tmp;
			tmp = line[38];
			line[38] = '\0';
			x = atof(&line[30]);
			line[38] = tmp;

			tmp = line[46];
			line[46] = '\0';
			y = atof(&line[38]);
			line[46] = tmp;

			tmp = line[54];
			line[54] = '\0';
			z = atof(&line[46]);
			line[54] = tmp;

			_atom_list[last_chain][res_ID-1][atom_name]=Atom(chain_ID, res_ID, amino_accid, atom_name, atom_serial_number, x, y, z);
		}
	}
	fclose(pdb_F);
	_sequences[last_chain] = seq;
	delete[] atom_name;
}




Contacts *
PDB::calculate_contacts(char chain, double min_dist, char *seq_name)
{

	if (chain == '#')
		chain = _atom_list.begin()->first;
	const double r_probe=1.4 * 2;
	double ca_dist, dist, lim;

	vector< map<string, Atom> > &atoms = _atom_list[chain];
	unsigned int num_residues = atoms.size();
	map<string, Atom>::iterator it1, it2, end1, end2;
	bool in_contact = false;


	Contacts* contacts = new Contacts(num_residues, _pdb_f, chain);
	contacts->set_seq_name(seq_name);
	contacts->set_seq(_sequences[chain]);

	unsigned int res_id_A, res_id_B;


	#pragma omp parallel for shared(num_residues, min_dist, atoms, contacts) private(res_id_A, it1, it2, end1, end2, in_contact, ca_dist, dist, lim, res_id_B) schedule(dynamic, 10)
	for (res_id_A = 0; res_id_A < num_residues; ++res_id_A)
	{
		for (res_id_B = res_id_A+min_dist; res_id_B < num_residues; ++res_id_B)
		{
			if ((atoms[res_id_A].count("CA")) && (atoms[res_id_B].count("CA")))				
				ca_dist = atoms[res_id_A]["CA"].compute_distance(atoms[res_id_B]["CA"]);
			else
				ca_dist = 0;
			if (ca_dist < 22.5)
			{
				end1 = atoms[res_id_A].end();
				for ( it1=atoms[res_id_A].begin() ; it1 != end1; ++it1 )
				{

					if (!(it1->first.compare("C")) || (!it1->first.compare("CA")) || (!it1->first.compare("N")) || (!it1->first.compare("O")) || (!it1->first.compare("OXT")))
						continue;

					end2 = atoms[res_id_B].end();
					for ( it2=atoms[res_id_B].begin() ; it2 != end2; ++it2 )
					{
						if ((!it2->first.compare("C")) || (!it2->first.compare("CA")) || (!it2->first.compare("N")) || (!it2->first.compare("O")) || (!it2->first.compare("OXT")))
							continue;
						
						dist = it1->second.compute_distance(it2->second);
						lim= it1->second.radius() + it2->second.radius() + r_probe;

						// Once a contact is found no other atoms between these two residues have to be examined.
						if(dist < lim) {
							#pragma omp critical
							{
								contacts->add_pair(res_id_A, res_id_B);
							}
							in_contact = true;
							break;
						}
					}
					if (in_contact)
					{
						in_contact = false;
						break;
					}
				}
			}
		}
	}
	return contacts;
}

