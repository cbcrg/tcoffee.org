#!/soft/bin/python
# -*- coding: iso-8859-1 -*-

import sys
import re
import os
#import modul_aln as aln_modul

from optparse import OptionParser

def read_clustalw(file_name):
	f_file = file(file_name)
	h_seq = {}
	#get sequence names
	f_file.readline()
	f_file.readline()
	#get sequences
	regular_ex =re.compile(r"(\S+)\s+(\S+.*)\n")
	while True:
		line = f_file.readline()
		if len(line) == 0:
			break
		if line[0] != ' ':
			m = regular_ex.match(line)
			if m != None:
				name = m.group(1)
				if h_seq.has_key(name):
					h_seq[name] += m.group(2)
				else:
					h_seq[name] = m.group(2)
	f_file.close()
	return h_seq



#def parse_struct(file_name):
#	struc_file = open(file_name, "r")
#	for line in struc_file:
#		if line[0] != '#':
#			return line
		
		
def parse_match_file(match_name):
	match_h = {}
	pairs_for_sequences = {}
	pairs4line = []	
	members_for_clusters = 0
	match_file = open(match_name, "r")
	pos=-1
	for line in match_file:
		line = line[:-1]
		if line[0] == 'p':
			break
		if line[0] == '#':
			pairs4line.append(0)
			pos+=1
			continue
		pairs4line[pos] += 1
		#match_h contains all the different kinds of pair whitin the cluster and their ammount
		if line in match_h:
			match_h[line]+=1
		else:	
			match_h[line]=1
	tot=0
	for keys in match_h:
		tot += match_h[keys] * (match_h[keys] - 1) / 2;

	pos += 1
	max_pairs = 0;
	for seq1 in range (0,pos):
		for seq2 in range(seq1+1, pos):
			max_pairs += min(pairs4line[seq1], pairs4line[seq2])
	print float(tot)/float(max_pairs)

	match_file.close()
	match_file = open(match_name, "r")
	for line in match_file:
		line = line[:-1]
		if line[0] == 'p':
			break
		if line[0] == '#':
			seq_name = line[1:]
			pairs_for_sequences[seq_name]={}
			continue
		pair = line.split()
		pairs_for_sequences[seq_name][pair[0]] = match_h[line]/float(pos)
		pairs_for_sequences[seq_name][pair[1]] = match_h[line]/float(pos)
	match_file.close()
	return pairs_for_sequences




def sum_of_pairs (match_name):
	allStructures = {}
	match_file = open(match_name, "r")
	sumOfPairs = 0
	for line in match_file:
		line = line[:-1]
		if line[0] == 'p':
			break
		if line[0] == '#':
			seqName = line
			allStructures[seqName] = {}
			continue
		allStructures[seqName][line] = 1
	allSequenceNames = allStructures.keys()
	numberOfSequences = len(allSequenceNames) 
	for index1 in range (0,numberOfSequences):
		seqName1 = allSequenceNames[index1]
		currentPairs1 = allStructures[seqName1]
		for index2 in range (index1+1,numberOfSequences):
			seqName2 = allSequenceNames[index2]
			currentPairs2 = allStructures[seqName2]
		
			#pair comparison for each sequence
			for pair1 in currentPairs1.iterkeys():
				if pair1 in currentPairs2:
					sumOfPairs += 1
	print sumOfPairs
					





################################


parser = OptionParser()
parser.add_option("-a", "--aln_name", dest="aln_name", help="The alignment file name")
#parser.add_option("-s", "--str_name", dest="struc_folder", help="The structure folder name. It is 'pdbFix-output' folder produced while running pipeline_sara_RUNITONCUBA_V2.sh")
parser.add_option("-m", "--match_name", dest="match_name", help="Specify the .str file produced while running the runSaraBenchmark script")

(options, args) = parser.parse_args()
	
aln_name        = options.aln_name
#struc_folder    = options.struc_folder
match_name      = options.match_name


#####


out_file_name = aln_name + ".color_cache"
out_file      = open(out_file_name, "w");

pairs_for_sequences = parse_match_file(match_name)
aln_h               = read_clustalw(aln_name)
#sumOfPairScore      = sum_of_pairs (match_name)

for key in aln_h:
	out_file.write(">"+key+"\n")
	sequence = aln_h[key];
	#if not os.path.exist(struc_folder + '/' + key[:4] + '.pdb.' + key[5:] + '.pairs')
	#	continue
	#struct = parse_struct(struc_folder + '/' + key[:4] + '.pdb.' + key[5:] + '.pairs')
	for i in range(0, len(sequence)):
		if sequence[i] != '-':
			if str(i+1) in pairs_for_sequences[key]:
				value = pairs_for_sequences[key][str(i+1)]
				if value <= 0.2:
					out_file.write("1")
				elif value <= 0.4:
					out_file.write("2")
				elif value <= 0.6:
					out_file.write("3")
				elif value <= 0.8:
					out_file.write("4")
				elif value <= 1:
					out_file.write("5")
			else:
				out_file.write("0")
			
	out_file.write("\n")

