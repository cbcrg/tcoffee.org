#!/soft/bin/python
# -*- coding: iso-8859-1 -*-

import sys, os, re
import shlex, subprocess
from optparse import OptionParser
import tempfile
from signal import signal, SIGTERM
from sys import exit
import atexit



#Signal Handling - Deleting temporary files
def cleanup():
	print "Deleting temporary files"
	if os.path.isfile(tmp_file_name):
		os.remove(tmp_file_name)

if __name__ == "__main__":
	from time import sleep
	atexit.register(cleanup)

    # Normal exit when killed
	signal(SIGTERM, lambda signum, stack_frame: exit(1))

    #sleep(10)


def takeNames(bench):
	
	methodFile = open(bench+"/methods.txt","r");
	lines = methodFile.readlines()
	orderedNames=[]
	for line in lines: 
		orderedNames.append(line.split(";")[1].strip())
	return orderedNames


tmp_file_name = ""


#Option parsing
parser = OptionParser()
parser.add_option("-f", "--aln_directory", dest="bench_directory", help="Folder with alignments")
parser.add_option("-o", "--out_file", dest="outfile_name", help="out_file")
parser.add_option("-d", "--data_generation_only", action="store_true", dest="data_gen_only", default = False, help="only file is generated [default: %default]")
parser.add_option("-a", "--analyis_only", dest="analysis_only", action="store_true", default = False, help="only the analisis is done [default: %default]")
parser.add_option("-m", "--max_distance", dest="max_distance", type="int" , default = 50 , help="max dist parameter proposed by cedric [default: %default]")
parser.add_option("-g", "--gapped", dest="gappedVal", type="int" , default = 0 , help="gapped parameter proposed by cedric [default: %default]")
parser.add_option("-i", "--infile", dest="infile_name", help="Only in compination with '--analysis_only'")

(options, args) = parser.parse_args()


if options.data_gen_only & options.analysis_only:
	sys.stderr.write("Parameters '-d' and '-a' cannot be used at the same time!\n")
	exit(1)


if (not options.data_gen_only) & (not options.analysis_only):
	options.analysis_only= True
	options.data_gen_only= True
	options.infile_name = options.outfile_name

options.aln_directory=options.bench_directory+'/OutDir'

folders=takeNames(options.bench_directory)
#generate result file
if options.data_gen_only:

	re_eval = re.compile(r"\s+TOTAL\s+EVALUATED:\s+(\S+)\s+")
	re_nirmsd = re.compile(r"\s+TOTAL\s+NiRMSD:\s+(\S+)\s+")
	re_irmsd = re.compile(r"\s+TOTAL\s+iRMSD:\s+(\S+)\s+")


	alignment_path = options.aln_directory

	result_f = open(options.outfile_name, "w")
	for alignment_prog in folders:
		cmd = "find " + alignment_path + '/' + alignment_prog + " -name \*.aln"
		pipe = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).stdout


		alignment_names=pipe.readlines()

		for alignment_name in alignment_names:
			alignment_name=alignment_name.strip()
			#print alignment_name
			fd, tmp_file_name = tempfile.mkstemp(prefix="irmsd_calc_", dir = "./")
			os.close(fd)

			#print alignment_name + " ",
			tmp_name = "tmp_up" + str(options.gappedVal) + str(options.max_distance)
			os.system("t_coffee -other_pg seq_reformat -in " + alignment_name + " -action +upper > " + tmp_name)
			#print "t_coffee -other_pg seq_reformat -in " + alignment_name + " -action +upper > tmp_up"
			#os.system("mv " + tmp_name + " "  + alignment_name)
			#print "t_coffee -other_pg irmsd "+ alignment_name +" -template_file " + options.bench_directory + "/TEMPLATEFILE  -maximum_distance 99 -n_excluded_nb 1 > "+tmp_file_name
			#print ("t_coffee -other_pg irmsd "+ alignment_name +" -template_file " + options.bench_directory + "/TEMPLATEFILE  -maximum_distance 99 -n_excluded_nb 1 -pdb_min_sim 0 -gapped " + str(options.gappedVal)+" > "+tmp_file_name+" 2>> err")
			os.system("t_coffee -other_pg irmsd "+ tmp_name +" -template_file " + options.bench_directory + "/TEMPLATEFILE  -maximum_distance " + str(options.max_distance)+" -n_excluded_nb 1 -pdb_min_sim 0 -gapped " + str(options.gappedVal)+" > "+tmp_file_name+" 2>> err" + tmp_name )


			#T-Coffee sometimes broke and didn't produce an output, in this cases t_coffee is run again
			#while (os.path.getsize(tmp_file_name) == 0):
				#print "NEXT"
				#os.system("t_coffee -other_pg irmsd "+ alignment_name[:-1] +" -template_file /users/cn/ckemena/projects/sara/data/TEMPLATEFILE  -maximum_distance 99 -n_excluded_nb 1 > " +tmp_file_name + " 2>> err")


			erg_f = open(tmp_file_name,"r");

			line = erg_f.readline()
			while line[:6] != "#TOTAL":
				line = erg_f.readline()

			line = erg_f.readline()
			m = re_eval.match(line)
			if m != None:
				evalu = m.group(1)
			else:
				print line
				print "ERROR IN PARSING EVALUATED OUTPUT"
				exit(1)
			line  = erg_f.readline()
			line  = erg_f.readline()
			m     = re_irmsd.match(line)
			#irmsd parsing
			if m != None:
				irmsd = float(m.group(1))
			else:
				print line
				print "ERROR IN PARSING IRMSD OUTPUT"
				exit(1)

			#Nirmsd parsing
			line  = erg_f.readline()
			m     = re_nirmsd.match(line)

			if m != None:
				nirmsd = float(m.group(1))
			else:
				print line
				print "ERROR IN PARSING NIRMSD OUTPUT"
				exit(1)
			

			

			#print str(evalu) + " " + str(round(nirmsd,2))
			result_f.write(alignment_name + " " + str(evalu) + " " + str(irmsd) + " " + str(nirmsd) + "\n")
			erg_f.close()
			os.remove(tmp_file_name)


#Calculate winner
if options.analysis_only:
	result_f = open(options.infile_name, "r")
	re_result = re.compile(r"(\S+)\s+(\S+)\s+(\S+)\s+(\S+)")
	lines = result_f.readlines()
	results_nirmsd_h = {}
	results_irmsd_h = {}
	#read data from file and store it in hash
	for line in lines:
		m = re_result.match(line)
		if m != None:
			name = m.group(1)
			result_irmsd = float(m.group(3))
			result_nirmsd = float(m.group(4))
			splitted = name.split("/")
			aln_method=splitted[len(splitted)-2]
			cluster_num = cluster_num = splitted[len(splitted)-1][:splitted[len(splitted)-1].find(".")]


			if aln_method in results_nirmsd_h:
				results_nirmsd_h[aln_method][cluster_num] = result_nirmsd
				results_irmsd_h[aln_method][cluster_num] = result_irmsd
			else:
				results_nirmsd_h[aln_method] = {}
				results_nirmsd_h[aln_method][cluster_num] = result_nirmsd
				results_irmsd_h[aln_method] = {}
				results_irmsd_h[aln_method][cluster_num] = result_irmsd


	result_f.close()
	result_f = open(options.infile_name, "a")
	#evaluate data all against all
	methods = results_nirmsd_h.keys()
	cluster = results_nirmsd_h[methods[0]].keys()
	cluster.sort()

	winner_nirmsd  = {}
	average_nirmsd = {}
	winner_irmsd   = {}
	average_irmsd  = {}

	for method in methods:
		winner_nirmsd[method]  = 0
		average_nirmsd[method] = 0
		winner_irmsd[method]   = 0
		average_irmsd[method]  = 0

	for cluster_num in cluster:
		best_nirmsd = float('inf')
		best_index_nirmsd = []
		best_irmsd = float('inf')
		best_index_irmsd = []
		for method in methods:
			average_nirmsd[method] += results_nirmsd_h[method][cluster_num]
			average_irmsd[method]  += results_irmsd_h[method][cluster_num]
			if results_nirmsd_h[method][cluster_num] < best_nirmsd:
				best_nirmsd = results_nirmsd_h[method][cluster_num]
				best_index_nirmsd=[method]
			elif results_nirmsd_h[method][cluster_num] == best_nirmsd:
				best_index_nirmsd.append(method)

			if results_irmsd_h[method][cluster_num] < best_irmsd:
				best_irmsd = results_irmsd_h[method][cluster_num]
				best_index_irmsd=[method]
			elif results_irmsd_h[method][cluster_num] == best_irmsd:
				best_index_irmsd.append(method)

		for method in best_index_nirmsd:
			winner_nirmsd[method] += 1;
		for method in best_index_irmsd:
			winner_irmsd[method] += 1;

	cluster_num = len(cluster)
	for method in methods:
		average_nirmsd[method] /= cluster_num
		average_irmsd[method] /= cluster_num

	#result2_f = open(options.outfile_name2, "w")
	result_f.write("Method #cl-n avg-nirmsd\n")
	for method in folders:
		#print name_end[method] + ": " + str(winner[method]) + " " + str(average[method])
		print method + ": " + str(winner_nirmsd[method]) + " " + str(average_nirmsd[method])
		result_f.write(method + ": " + str(winner_nirmsd[method]) + " " + str(round(average_nirmsd[method],2))+"\n")
		#result2_f.write(method + " " + str(winner_irmsd[method]) + " " + str(round(average_irmsd[method],2))+ " " + str(winner_nirmsd[method]) + " " + str(round(average_nirmsd[method],2))+"\n")
	#result2_f.close()
	#result_f.write("\nirmsd\n")
	#for method1 in folders:
	#	#print name_end[method1],
	#	print method1,
	#	result_f.write(method1 + " ")
	#print
	#result_f.write("\n")
	#for method1 in folders:
		#print name_end[method1],
	#	print method1,
	#	result_f.write(method1 + " ")
	#	for method2 in folders:
	#		if method1 == method2:
	#			print "-",
	#			result_f.write("- ")
	#			continue
	#		winner=0
	#		for cluster_num in cluster:
	#			if results_nirmsd_h[method2][cluster_num] < results_nirmsd_h[method1][cluster_num]:
	#				winner += 1
	#		print winner,
	#		result_f.write(str(winner) + " ")
	#	print
	#	result_f.write("\n")

	#result_f.write("\nnirmsd\n")
	for method1 in folders:
		#print name_end[method1],
		print method1,
		result_f.write(method1 + " ")
	result_f.write("\n")
	print
	for method1 in folders:
		#print name_end[method1],
		print method1,
		result_f.write(method1 + " ")
		for method2 in folders:
			if method1 == method2:
				print "-",
				result_f.write("- ")
				continue
			winner=0
			for cluster_num in cluster:
				if results_nirmsd_h[method2][cluster_num] < results_nirmsd_h[method1][cluster_num]:
					winner += 1
			print winner,
			result_f.write(str(winner) + " ")
		print
		result_f.write("\n")

	result_f.write("\n")	
	#print average

	result_f.close()	

