#!/bin/sh
BENCH=`echo $PWD | tr -d "\n"`

export PDB_DIR=$BENCH"/PDBdir"
export NO_REMOTE_PDB_DIR=1


$BENCH/scripts/3SP.pl -c $BENCH/BraliDARTS/ -s $BENCH/pdbFix/ -m $BENCH/methods.txt -alignmentStructureAgreement $BENCH/scripts/alignmentStructureAgreement.py -o $BENCH

$BENCH/scripts/niRMSD.py -f $BENCH -o $BENCH/niRMSD.out


