#!/usr/bin/env perl

while (<>) 
  {
   ($tc, $st)=/(\S+)/g;
   system "aln_compare -al1 ../$tc.ref_aln -al2 ../$tc.ref_aln -io_format p| grep $st | sort -n -k3 > $$.1"; 
   open F, "$$.1";
   print "$tc $st ";
   while (<F>){

     @l=/(\S+)/g;

     printf ("%s " ,($l[0] eq $st)?$l[1]:$l[0]);
   
   }
   close (F);
   unlink "$$.1";
   print "\n";
  }

