#!/usr/bin/env python
import sys
import math
from Bio import SeqIO
from Bio import AlignIO
from Bio import Alphabet
from Bio.Alphabet import IUPAC
from Bio.Align import AlignInfo
from Bio import SubsMat

##missing - figure out how to do do this by googling biopython resources - about 10 lines are required, no loops
