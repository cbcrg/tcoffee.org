#!/usr/bin/env python

from Bio import SeqIO

for #missing1
    print(record.seq)

