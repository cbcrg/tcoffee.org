
#!/usr/bin/env perl
#
#   A course on sequence Alignments
# 	Cedric Notredame 2001
#   All rights reserved
#   Files can be redistributed without permission
#   Comercial usage is forbiden
#   Hello World Example

print "Hello World\n";
                                                         
